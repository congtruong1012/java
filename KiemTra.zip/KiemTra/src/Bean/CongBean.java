package Bean;

import java.util.Date;

public class CongBean {
	private String ma;
	private String tenhang;
	private String tenncc;
	private long soluong;
	private long gia;
	private String anh;
	public String getMa() {
		return ma;
	}
	public void setMa(String ma) {
		this.ma = ma;
	}
	public String getTenhang() {
		return tenhang;
	}
	public void setTenhang(String tenhang) {
		this.tenhang = tenhang;
	}
	public String getTenncc() {
		return tenncc;
	}
	public void setTenncc(String tenncc) {
		this.tenncc = tenncc;
	}
	public long getSoluong() {
		return soluong;
	}
	public void setSoluong(long soluong) {
		this.soluong = soluong;
	}
	public long getGia() {
		return gia;
	}
	public void setGia(long gia) {
		this.gia = gia;
	}
	public String getAnh() {
		return anh;
	}
	public void setAnh(String anh) {
		this.anh = anh;
	}
	public CongBean(String ma, String tenhang, String tenncc, long soluong, long gia, String anh) {
		super();
		this.ma = ma;
		this.tenhang = tenhang;
		this.tenncc = tenncc;
		this.soluong = soluong;
		this.gia = gia;
		this.anh = anh;
	}
	public CongBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
