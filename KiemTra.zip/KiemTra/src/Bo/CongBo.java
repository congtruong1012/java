package Bo;

import java.util.ArrayList;

import Bean.CongBean;
import Dao.CongDao;

public class CongBo {
	public ArrayList<CongBean> ds;
	public ArrayList<CongBean> getds() throws Exception {
		CongDao cd = new CongDao();
		ds = cd.getds();
		return ds;
	}
	public ArrayList<CongBean> TimKiem(String key) {
		ArrayList<CongBean> tam = new ArrayList<CongBean>();
		for(CongBean c: ds) {
			if(c.getTenhang().trim().toLowerCase().contains(key.trim().toLowerCase())||c.getTenncc().trim().toLowerCase().contains(key.trim().toLowerCase())){
				tam.add(c);
			}
		}
		return tam;
	}

}
