package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import Bean.CongBean;

public class CongDao {
	dungchung dc= new dungchung();
	public ArrayList<CongBean> getds() throws Exception {
		ArrayList<CongBean> ds = new ArrayList<CongBean>();
		dc.KetNoi();
		String sql = "select * from Cong";
		PreparedStatement cmd = dc.cn.prepareStatement(sql);
		ResultSet rs = cmd.executeQuery();
		while(rs.next()) {
			String ma = rs.getString("ma");
			String tenhang = rs.getString("tenhang");
			String tenncc = rs.getString("tenncc");
			long soluong = rs.getLong("soluong");
			long gia = rs.getLong("gia");
			String anh = rs.getString("anh");	
			CongBean c = new CongBean(ma, tenhang, tenncc, soluong, gia, anh);
			ds.add(c);
		}
		return ds;
	}
}
