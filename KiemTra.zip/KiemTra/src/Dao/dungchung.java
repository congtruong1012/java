package Dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class dungchung {

	public Connection cn;
	public void KetNoi() throws Exception {
		//b1: Xac dinh HQTCSDL
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.print("Da xac dinh HQTCSDL");
		//b2 Ket noi vao csdl
		String url="jdbc:sqlserver://DESKTOP-7VC9MRJ\\SQLEXPRESS:1433;databaseName=TruongChiCong;user=sa; password=123123";
		cn=DriverManager.getConnection(url);
		System.out.print("Da ket noi");
	}
}
